package br.com.orcamentobd.orcamentoBD.controllers;

import br.com.orcamentobd.orcamentoBD.model.Lancamento;
import br.com.orcamentobd.orcamentoBD.services.LancamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/lancamento")
public class LancamentoController {
    @Autowired
    private LancamentoService lancamentoService;
    public ResponseEntity<Lancamento> inserir (@RequestBody Lancamento lancamento){
        Lancamento lancamentoesalvar = lancamentoService.salvar(lancamento);
        return ResponseEntity.status(HttpStatus.CREATED).body(lancamentoesalvar);
    }
}
