package br.com.orcamentobd.orcamentoBD.services;

import br.com.orcamentobd.orcamentoBD.model.Cliente;
import br.com.orcamentobd.orcamentoBD.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;
    public Cliente salvar (Cliente cliente){return clienteRepository.save(cliente);}
}
