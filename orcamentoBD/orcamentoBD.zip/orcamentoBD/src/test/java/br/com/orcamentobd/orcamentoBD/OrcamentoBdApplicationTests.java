package br.com.orcamentobd.orcamentoBD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrcamentoBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
