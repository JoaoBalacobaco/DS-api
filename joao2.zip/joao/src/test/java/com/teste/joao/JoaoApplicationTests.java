package com.teste.joao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
