package com.teste.joao.domain.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Generated;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity

@Table(name = "curso")
public class Curso {
    @ManyToOne
    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "o nome e obrigatorio")
    private String nome;
    @CreationTimestamp
    @Column(name = "datacadastro", columnDefinition = "datetime")
    private LocalDateTime datacadastro;
    @CreationTimestamp
    @Column(name = "dataatualizacao", columnDefinition = "datetime")
    private LocalDateTime dataatuaçizacao;
}
