package com.teste.joao.domain.service;
public class CursoService {
}
