package com.teste.joao.domain.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity

@Table(name = "aluno")
public class Aluno {
    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O nome e ogrigatorio")
    private String nome;

    @ManyToOne
    @JoinColumn(name = "id")
    private Curso curso;

    @CreationTimestamp
    @Column(name = "datacadastro", columnDefinition = "datetime")
    private LocalDateTime datacadastro;
    @CreationTimestamp
    @Column(name = "dataatualizacao", columnDefinition = "datetime")
    private LocalDateTime dataatuaçizacao;
}
