package com.teste.joao.api.Controller;

import com.teste.joao.domain.model.Aluno;
import com.teste.joao.domain.repository.AlunoRepository;
import com.teste.joao.domain.service.AlunoServide;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import java.util.Optional;

@RestController
@RequestMapping("/aluno")
public class AlunoController {

    @Autowired
    private AlunoRepository alunoRepository;

    @Autowired
    private AlunoServide alunoServide;
    @GetMapping
    public List<Aluno> listar(){ return alunoRepository.findAll(); }

    @GetMapping("/{cidadeId}")
    public ResponseEntity<Aluno> buscar(@PathVariable Long Id) {
        Optional<Aluno> aluno = alunoRepository.findById(Id);

        if (aluno.isPresent()){
            return ResponseEntity.ok(aluno.get());
        }
        return ResponseEntity.notFound().build();
    }
    @PostMapping
    public ResponseEntity<Aluno> adicionar(@RequestBody Aluno aluno) {
        aluno = alunoServide.salvar(aluno);
        return ResponseEntity.status(HttpStatus.CREATED).body(aluno);
    }

    @PutMapping("/{cidadeId}")
    public ResponseEntity <Aluno> atualizar(@PathVariable Long Id, @RequestBody Aluno aluno) {
        Optional<Aluno> alunoAtual = alunoRepository.findById(Id);

        if (alunoAtual.isPresent()){
            BeanUtils.copyProperties(aluno, alunoAtual, "id");

            Aluno cidadeSalva = alunoServide.salvar(alunoAtual.get());
            return ResponseEntity.ok(cidadeSalva);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{cidadeId}")
    public ResponseEntity<Aluno> remover(@PathVariable Long Id) {
        try {
            alunoServide.excluir(Id);
            return ResponseEntity.notFound().build();
        }

        catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }

        catch (EntidadeEmUsoException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
