package com.teste.joao.domain.repository;

import com.teste.joao.domain.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CursoReporitory extends JpaRepository<Curso, Long> {
    @Query("From Aluno c join fetch c.curso")
    List<Curso> findAll();
}
