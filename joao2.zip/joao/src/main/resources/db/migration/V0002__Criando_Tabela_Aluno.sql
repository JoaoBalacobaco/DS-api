create table aluno(
    id int not null primary key auto_increment,
    nome varchar (100)
    curso bigint not null
    datacadastro datetime,
    dataatualizacao datetime
)engine=InnoDB default charset=utf8;