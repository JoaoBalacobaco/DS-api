create table curso(
    id int not null primary key auto_increment,
    nomecurso varchar(100)
    datacadastro datetime,
    dataatualizacao datetime
)engine=InnoDB default charset=utf8;