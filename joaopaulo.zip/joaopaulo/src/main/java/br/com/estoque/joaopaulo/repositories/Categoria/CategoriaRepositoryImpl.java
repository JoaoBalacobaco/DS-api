package br.com.estoque.joaopaulo.repositories.Categoria;

import br.com.estoque.joaopaulo.model.Categoria;
import br.com.estoque.joaopaulo.repositories.Filters.CategoriaFilter;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public class CategoriaRepositoryImpl implements CategoriaRepositoryQuery{
    @PersistenceContext
    private EntityManager manager;
    @Override
    public Page<Categoria> filtrar(CategoriaFilter categoriaFilter, Pageable pageable) {
        CriteriaBuilder builder = manager.getCriteriaBuilder();
        
        return null;
    }
}
