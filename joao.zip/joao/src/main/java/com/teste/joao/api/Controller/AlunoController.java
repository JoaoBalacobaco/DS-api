package com.teste.joao.api.Controller;public class AlunoController {
}
