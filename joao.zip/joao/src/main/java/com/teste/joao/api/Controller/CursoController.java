package com.teste.joao.api;public class Curso {
}
