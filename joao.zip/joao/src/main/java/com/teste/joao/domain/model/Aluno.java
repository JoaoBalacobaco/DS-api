package com.teste.joao.domain.model;public class Aluno {
}
