package com.teste.joao.domain.repository;public interface CursoReporitory {
}
