package br.com.estoque.joaopaulo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoaopauloApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoaopauloApplication.class, args);
	}

}
