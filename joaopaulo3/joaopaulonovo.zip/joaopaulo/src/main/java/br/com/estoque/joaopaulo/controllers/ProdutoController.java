package br.com.estoque.joaopaulo.controllers;

import br.com.estoque.joaopaulo.model.Produto;
import br.com.estoque.joaopaulo.repositories.ProdutoRepository;
import br.com.estoque.joaopaulo.services.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping ("/produto")

public class ProdutoController {
    @Autowired
    private ProdutoService produtoService;
    @Autowired
    private ProdutoRepository produtoRepository;
    @GetMapping()
    public List<Produto> ListarTodosProdutos(){
        return produtoRepository.findAll(Sort.by("nomeproduto").ascending());
    }
    @RequestMapping()
    public ResponseEntity<Produto> inserirProduto(@RequestBody Produto produto){
        Produto produtosalvo = produtoService.salvar(produto);
        return ResponseEntity.status(HttpStatus.CREATED).body(produtosalvo);
    }
}
