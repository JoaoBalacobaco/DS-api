package br.com.estoque.joaopaulo.repositories.Filters;

public class CategoriaFilter {
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    private String nome;
}
