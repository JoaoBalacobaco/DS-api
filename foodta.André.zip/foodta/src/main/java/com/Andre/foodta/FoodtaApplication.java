package com.Andre.foodta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodtaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodtaApplication.class, args);
	}

}
