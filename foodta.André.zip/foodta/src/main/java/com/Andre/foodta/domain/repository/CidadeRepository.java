package com.Andre.foodta.domain.repository;

import com.Andre.foodta.domain.model.Cidade;
;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import java.util.List;


public interface CidadeRepository extends JpaRepository<Cidade, Long> {
    @Query("from Cidade r join fetch r.estado")
    List<Cidade> findAll();


}
