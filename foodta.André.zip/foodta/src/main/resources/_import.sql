insert into tb_cozinha(nome_cozinha) values ('Brasileira');
insert into tb_cozinha(nome_cozinha) values ('Italiana');
insert into tb_cozinha(nome_cozinha) values ('Tailandesa');

insert into tb_restaurante(nome,taxa_frete,cozinha_id) values ('Brasileira',3.3,1 );
insert into tb_restaurante(nome,taxa_frete,cozinha_id ) values ('Italiana', 3.23,2);
insert into tb_restaurante(nome,taxa_frete,cozinha_id) values ('Tailandesa', 4.23,3);
