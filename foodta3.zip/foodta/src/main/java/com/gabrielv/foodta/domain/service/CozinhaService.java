package com.gabrielv.foodta.domain.service;

import com.gabrielv.foodta.domain.exception.EntidadeEmUsoException;
import com.gabrielv.foodta.domain.exception.EntidadeNaoEncontradaException;
import com.gabrielv.foodta.domain.model.Cozinha;
import com.gabrielv.foodta.domain.repository.CozinhaRepository;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;

@Service
public class CozinhaService {
    @Autowired
    private CozinhaRepository cozinhaRepository;

    public Cozinha salvar(Cozinha cozinha) {
        return cozinhaRepository.salvar(cozinha);
    }

    public void excluir (Long id){
        try{
            cozinhaRepository.remover(id);
        }
        catch (DataIntegrityViolationException e){
            throw new EntidadeEmUsoException(String.format("Cozinha ou codigo %d nao pode ser removida pois esta em uso", id));
        }
        catch (EmptyResultDataAccessException e){
            throw new EntidadeNaoEncontradaException(String.format("Nâo existe cadrastro de cozinha com o codigo %d", id));
        }
    }

}
