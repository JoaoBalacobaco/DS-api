package com.gabrielv.foodta.domain.exception;

public class EntidadeNaoEncontradaException extends RuntimeException{
    public EntidadeNaoEncontradaException(String mensagen){
        super(mensagen);
    }
}
