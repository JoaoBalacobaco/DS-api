package br.com.orcamentobd.orcamentoBD.repositories.Municipio;

import br.com.orcamentobd.orcamentoBD.model.Municipio;
import br.com.orcamentobd.orcamentoBD.repositories.Filters.MunicipioFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface MunicipioRepositoryQuery {
    Page<Municipio> filtrar(MunicipioFilter municipioFilter, Pageable pageable);
}
