package br.com.orcamentobd.orcamentoBD.repositories.Filters;

import java.math.BigDecimal;
import java.time.LocalDate;

public class LancamentoFIlter {
    private LocalDate date;

    private String tipolancamento;
    private BigDecimal valorlancamento;

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getTipolancamento() {
        return tipolancamento;
    }

    public void setTipolancamento(String tipolancamento) {
        this.tipolancamento = tipolancamento;
    }

    public BigDecimal getValorlancamento() {
        return valorlancamento;
    }

    public void setValorlancamento(BigDecimal valorlancamento) {
        this.valorlancamento = valorlancamento;
    }
}
